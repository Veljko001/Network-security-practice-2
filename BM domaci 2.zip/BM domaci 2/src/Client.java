import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.spec.KeySpec;
import java.util.Base64;

public class Client {

    public Client() throws Exception {
        Socket socket = new Socket("localhost", 3035);

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        System.out.println(in.readLine());
        System.out.println("Unesi kljuc: ");
        String kljuc = tin.readLine();

        while (true) {
            System.out.println("Poslajite tekst: ");
            String tekst = tin.readLine();

            String sifrovan = sifruj3DES(kljuc, tekst);
            out.println(sifrovan);

            if (tekst.equals("EXIT")) {
                System.out.println("Zavrsena komunikacija");
                break;
            }
        }

        socket.close();

    }

    private String sifruj3DES(String key, String tekst) throws Exception {
        // Korak 1
        byte[] keyBajt = key.getBytes();
        byte[] tekstBajt = tekst.getBytes();

        // Korak 2
        KeySpec keySpec = new DESedeKeySpec(keyBajt);
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DESede");
        SecretKey secretKey = secretKeyFactory.generateSecret(keySpec);

        // Korak 3
        Cipher cipher = Cipher.getInstance("DESede");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] enkBajt = cipher.doFinal(tekstBajt);

        // Korak 4
        Base64.Encoder encoder = Base64.getEncoder();
        String enkriptovano = encoder.encodeToString(enkBajt);

        return enkriptovano;
    }

    public static void main(String[] args) throws Exception {
        new Client();
    }
}
