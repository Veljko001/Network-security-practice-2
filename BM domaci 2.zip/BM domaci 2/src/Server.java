import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;

public class Server {

    public Server() throws Exception {
        ServerSocket sc = new ServerSocket(3035);
        Socket socket = sc.accept();

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        String kljuc = napravi3DESKljuc();
        out.println("Dobrodosli!");
        System.out.println("Kljuc je: " + kljuc);

        while (true) {
            String enkriptPoruka = in.readLine();
            System.out.println("Client: " + enkriptPoruka);
            String dekriptPoruka = desifruj3DES(kljuc, enkriptPoruka);
            System.out.println("Client: " + dekriptPoruka);

            if (dekriptPoruka.equals("EXIT")) {
                System.out.println("Zavrsena komunikacija");
                break;
            }
        }

        socket.close();
    }

    private String napravi3DESKljuc() {
        String kljuc = "RAFsecurity";
        SecureRandom random = new SecureRandom();
        while (kljuc.length() < 24) { // 24 bytes = 192 bits
            //char c = (char) (random.nextInt(26) + 'a');
            int randType = random.nextInt(3); // 0 for lowercase letters, 1 for uppercase letters, 2 for digits
            char c;
            switch (randType) {
                case 0:
                    c = (char) (random.nextInt(26) + 'a');
                    break;
                case 1:
                    c = (char) (random.nextInt(26) + 'A');
                    break;
                case 2:
                    c = (char) (random.nextInt(10) + '0');
                    break;
                default:
                    c = ' '; // should not happen
                    break;
            }
            kljuc += c;
        }
        return kljuc;
    }

    private String desifruj3DES(String kljuc, String enkporuka) throws Exception {
        // Korak 1
        byte[] kljucBajt = kljuc.getBytes();
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] enkPorukaBajt = decoder.decode(enkporuka);

        // Korak 2
        KeySpec keySpec = new DESedeKeySpec(kljucBajt);
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DESede");
        SecretKey secretKey = secretKeyFactory.generateSecret(keySpec);

        // Korak 3
        Cipher cipher = Cipher.getInstance("DESede");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] dekriptPoruka = cipher.doFinal(enkPorukaBajt);

        String poruka = new String(dekriptPoruka);
        return poruka;
    }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}
